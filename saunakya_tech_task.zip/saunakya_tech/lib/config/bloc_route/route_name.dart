class AppRoute {
  static const initial = "/";
  static const countdownScreen = "/timer";
  static const userScreen="/user";
}
