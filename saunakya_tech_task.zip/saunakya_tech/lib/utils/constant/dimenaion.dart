// Screen size will be provided by here

const double mobileScreenSize = 300;
const double tabletScreen = 600;
const double webScreenSize = 800;
