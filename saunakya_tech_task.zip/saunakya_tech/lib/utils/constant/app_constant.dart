class AppConstant {
  static const String baseUrl = "API KEY";
  static const String deviceFirstTime = "Device_first_time";

}
