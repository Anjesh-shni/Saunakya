class User {
  final int id;
  final String name;
  final String username;
  final String email;
  final String phone;
  final String streetAddress;
  final String website;

  User({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.phone,
    required this.streetAddress,
    required this.website,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      username: json['username'],
      email: json['email'],
      phone: json['phone'],
      streetAddress: json['address']['street'],
      website: json['website'],
    );
  }
}
