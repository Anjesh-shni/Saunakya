class ApplicationState {
  final int index;
  ApplicationState({this.index = 0});
}
