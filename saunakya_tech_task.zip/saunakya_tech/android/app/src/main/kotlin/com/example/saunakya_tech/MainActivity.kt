package com.example.saunakya_tech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
